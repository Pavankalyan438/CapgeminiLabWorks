package capge.assignment9;

import java.util.*;
import java.util.concurrent.*;
public class Exercise1 
{
    public static void main(String[] args) 
    {
        Runnable task=()->{
            try {
            	while(true) {
                System.out.println("[ "+new Date()+" ]");
                TimeUnit.MILLISECONDS.sleep(10000);}
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        };
        ExecutorService es= Executors.newFixedThreadPool(10);
        es.execute(task);
           }
}
