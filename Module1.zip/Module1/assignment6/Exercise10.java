package capge.assignment6;

import java.util.Scanner;

public class Exercise10 {
	boolean cheching(String name){
		if(name.contains("_job")){
		int a=name.lastIndexOf("_job");
		if(a<8){
			System.out.println("Name is tooo short");
		}return true;
	}else System.out.println("with extension");
		return false;
	}
	

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the name with _job:extension");
		String name=s.next();
		Exercise10 e=new Exercise10();
		System.out.println(e.cheching(name));

	}

}
