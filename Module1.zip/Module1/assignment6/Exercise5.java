package capge.assignment6;

public class Exercise5 {
	int modifyNumber(int a){
		int d=0;
		String s=Integer.toString(a);
		int[] c=new int[s.length()];
		for(int j=0;j<s.length();j++){
			c[j]=s.charAt(j);
		}
		int i=0;
		StringBuffer sb=new StringBuffer();
		String s1=null;
		for( i=0;i<s.length()-1;i++){
			d=Math.abs(s.charAt(i)-s.charAt(i+1));
			sb.append(d);
		}
	sb.append(s.charAt((int)s.length()-1));
	String k=sb.toString();
	int l=Integer.parseInt(k);
	System.out.println(l);
	return d;
	}

	public static void main(String[] args) {
		Exercise5 e=new Exercise5();
		e.modifyNumber(4325);
		

	}

}
