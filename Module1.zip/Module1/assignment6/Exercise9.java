package capge.assignment6;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Exercise9 {

	public static void main(String[] args) throws ParseException {
		Scanner s=new Scanner(System.in);
		SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yy");
		Date d=new Date();
		Date d1=null;
		System.out.println("enter a date:");
		String s1=s.next();
		d1=sd.parse(s1);
		long l=d1.getTime()-d.getTime();
		long dg=l/(24*60*60*1000);
		long mg=dg/30;
		long yg=mg/12;
		System.out.println(dg+" "+mg+" "+yg);
		
		
	}

}
