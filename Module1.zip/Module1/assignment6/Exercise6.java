package capge.assignment6;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import org.omg.Messaging.SyncScopeHelper;

public class Exercise6 {

	public static void main(String[] args) throws IOException {
		File f=new File("counting.txt");
		PrintWriter fw=new PrintWriter("counting.txt");
		
		fw.println("hello pavan");
		fw.print("where");
		fw.println("how");
		fw.flush();
		fw.close();
		FileReader fr=new FileReader("counting.txt");
		int i=fr.read();
		int count2=1;
		while(i!=-1){
			System.out.println((char)i );
			char c=(char)i;
			if(c==' '){
			count2++;
			}
			i=fr.read();
		}
		System.out.println("no of words:"+count2);
		BufferedReader br=new BufferedReader(fr);
		
		int l=0,count=0,count1=0;
		String line=br.readLine();
		
		while(line!=null){
			System.out.println(line);
			count++;
			line=br.readLine();
		}
		System.out.println("no of lines:"+count);
		 l=(int) f.length();
		System.out.println("no. of chars:"+l);
		
	}

}
