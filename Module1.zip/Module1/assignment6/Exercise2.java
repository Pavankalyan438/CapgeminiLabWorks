package capge.assignment6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Exercise2 {

	public static void main(String[] args) throws IOException {
		FileReader fr=new FileReader("reading.txt");
		BufferedReader br=new BufferedReader(fr);
		String l=br.readLine();
		int i=1;
		while(l!=null){
			System.out.println((i++)+" "+l);
			l=br.readLine();
	}}

}
