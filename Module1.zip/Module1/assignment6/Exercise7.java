package capge.assignment6;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Exercise7 {

	public static void main(String[] args) throws IOException {
		String s;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter file name with .txt extension:");
		s=sc.next();
		/*int k=s.lastIndexOf("fu");
		System.out.println(k);
*/		if(s.contains(".txt")){
		File f=new File(s);
		//f.createNewFile();
		System.out.println("is file exist"+f.exists());
		System.out.println(f.canRead());
		System.out.println("is a file:"+f.isFile());
		System.out.println("is a directory:"+f.isDirectory());
		System.out.println("length:"+f.length());
}
else
	System.out.println("enter with extension:");

	}

}
