package capge.assignment6;

public class Exercise8 {
boolean stringCheck(String s){
	char[] ch=new char[s.length()];
	for(int i=0;i<s.length();i++){
		ch[i]=s.charAt(i);
	}
	for(int i=0;i<s.length()-1;i++){
		if(s.charAt(i)<s.charAt(i+1)){
			continue;	
		}
		else{
			System.out.println("false");
			System.exit(0);
		}
	}
	System.out.println("true");
	return true;
}
	public static void main(String[] args) {
		Exercise8 e=new Exercise8();
		e.stringCheck("anat");

	}

}
