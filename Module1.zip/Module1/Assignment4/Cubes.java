package Capg.Assignment4;

import java.util.Scanner;

public class Cubes {
	double cs=0;
	double cubing(int n)
	{
		while(n>0)
		{
		int r=n%10;
		 cs=cs+Math.pow(r, 3);
		 n=n/10;
		 
	}
		return cs;
	}

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the value n:");
		int n=s.nextInt();
		Cubes c=new Cubes();
		System.out.println(c.cubing(n));
		

	}

}
