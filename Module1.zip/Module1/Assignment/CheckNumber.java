package Capg.Assignment;

import java.util.Scanner;

public class CheckNumber {
	static int number;
	
	boolean ans()
	{
		
		 while(number>0)
		 {
			 int l,f;
			 f=number%10;
			 number=number/10;
			 l=number%10;
			 if(l<=f){
				 continue;
			 }
			 else{
				 return false;
				 
			 }
			  
		 }
		 return true;
	}
	

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number:");
		number=sc.nextInt();
		CheckNumber c=new CheckNumber();
		System.out.println(c.ans());

	}

}
