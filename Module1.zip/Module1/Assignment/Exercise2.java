package Capg.Assignment;

import java.util.Scanner;

public class Exercise2 {
int calculateDifference()
{
	int n,sum;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the n:");
	n=sc.nextInt();
	sum=(((n*(n+1)*(2*n+1)))/6)-(((n*(n+1))/2)*n*(n+1)/2);
	return sum;
	
}
	public static void main(String[] args) {
		Exercise2 e=new Exercise2();
		System.out.println(e.calculateDifference());

	}

}
