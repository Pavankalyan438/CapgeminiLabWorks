package Capg.Assignment;
import java.util.Scanner;
public class CalculateSum {
	int n,sum=0;
	int sum1()
	{
	for(int i=1;i<=n;i++)
	{
		if(i%3==0||i%5==0)
		{
			sum=sum+i;
		}
	}
	return sum;
}
	public static void main(String[] args) {
		CalculateSum s=new CalculateSum();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n:");
		s.n=sc.nextInt();
		System.out.println(s.sum1());
	}
}



