package Capg.Assignment;

import java.util.Scanner;

public class Exercise4 {
	boolean checkNumber()
	{
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the n:");
		
		
		n=sc.nextInt();
		if(n%2==0)
		{
			return true;
		}
		else
			return false;
	}

	public static void main(String[] args) {
		Exercise4 e=new Exercise4();
		System.out.println(e.checkNumber());

	}

}
