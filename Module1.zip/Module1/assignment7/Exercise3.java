package capge.assignment7;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise3 {
	Map getSquare(int[] a){
		HashMap hm=new HashMap();
		ArrayList al=new ArrayList();
		for(int i=0;i<a.length;i++){
			al.add(a[i]*a[i]);
		}
		for(int i=0;i<a.length;i++){
			hm.put(a[i], al.get(i));
		}
		return hm;
	}

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the length of array:");
		int l=s.nextInt();
		int[] a = new int[l];
		System.out.println("enter the elements;");
		for(int i=0;i<l;i++){
			a[i]=s.nextInt();
		}
		Exercise3 e=new Exercise3();
		System.out.println(e.getSquare(a));

	}

}
