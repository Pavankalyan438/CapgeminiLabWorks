package capge.assignment7;

import java.util.*;
import java.util.Map.Entry;

public class Exercise1 {
	List getValue(HashMap h1){
			Collection values = h1.values();
			ArrayList listOfValues = new ArrayList(values);
			Collections.sort(listOfValues);
			return listOfValues;		
			}
	public static void main(String[] args) {
		Exercise1 e=new Exercise1();
		HashMap m=new HashMap();
		m.put(1, 20);
		m.put(2, 98);
		m.put(3, 43);
		m.put(4, 10);
		
		System.out.println(e.getValue(m));
		

	}

}
