package capge.assignment7;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Exercise4 {
	Map getStudent(Map hm)
	{
		int i1=0;
		HashMap hm1=new HashMap();
		Set s=hm.entrySet();
		Iterator i=s.iterator();
		while(i.hasNext()){
			Entry entry=(Entry) i.next();
			int c=(int) entry.getValue();
			i1++;
			if(c>=90){
				hm1.put(i1, "gold");
			}else if(c>=80&&c<90){
				hm1.put(i1, "silver");
			}else if(c>=70&&c<80){
				hm1.put(i1, "bronze");
			}}return hm1;
	}

	public static void main(String[] args) {
		HashMap hm=new HashMap();
		hm.put(1, 93);
		hm.put(2, 89);
		hm.put(3, 78);
		Exercise4 ee=new Exercise4();
		System.out.println(ee.getStudent(hm));
	}

}
