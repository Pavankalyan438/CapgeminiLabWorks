package capge.assignment7;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise2 {
	Map countCharecter(char a[]){
		HashMap hm=new HashMap();
		for(int i=0;i<a.length;i++){
			 int count=1;
			if(a[i]=='1'){
				continue;
			}
			else{
				for(int j=i+1;j<a.length;j++){
					if(a[i]==a[j]){
						count++;
						a[j]='1';
					}
					
				}hm.put(a[i], count);
			}
			
		}
		return hm;
	}

	public static void main(String[] args) {
		Exercise2 e=new Exercise2();
		Scanner s=new Scanner(System.in);
		System.out.println("enter the string");
		String st=s.next();
		char[] c=new char[st.length()];
		for(int i=0;i<st.length();i++){
			c[i]=st.charAt(i);
		}
		System.out.println(e.countCharecter(c));
		

	}

}
