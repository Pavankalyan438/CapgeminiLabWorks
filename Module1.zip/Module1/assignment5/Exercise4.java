package Capg.assignment5;

import java.util.Scanner;
class InvalidName extends Exception{
	InvalidName(String msg)
	{
		super(msg);
	}
}

public class Exercise4 {
	static void nameCheck(String n1, String n2) throws Exception{
		if(n1.equals(" ")&&n2.equals(" ")){
			throw new InvalidName("not an employee name");
		}
		else
			System.out.println(n1+" "+n2);
	}

	public static void main(String[] args) throws Exception 
	{
		Scanner s=new Scanner(System.in);
		String empname1,empname2;
		System.out.println("Enter the names:");
		empname1=s.nextLine();
		empname2=s.nextLine();
		Exercise4 d=new Exercise4();
		nameCheck(empname1,empname2);
		

	}

}
