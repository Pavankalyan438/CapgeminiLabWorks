package Capg.Assignment3;

import java.util.Scanner;

public class Exersie3 {
	
	int[] getSorted(int a[]){
		int i;
		String b;
		for(i=0;i<a.length;i++){
		b=Integer.toString(a[i]);
		
		StringBuffer sb=new StringBuffer(b);
		sb.reverse();
		a[i]=Integer.parseInt(sb.toString());	
		}
		int c;
		for( i=0;i<a.length;i++){
			for(int j=0;j<a.length;j++){
				if(a[i]<a[j]){
					c=a[i];
					a[i]=a[j];
					a[j]=c;
				}
			}			
		}for(i=0;i<a.length;i++){
		System.out.println(a[i]);}
		return a;
		
	}

	public static void main(String[] args) {
		Exersie3 e=new Exersie3();
		Scanner s=new Scanner(System.in);
		System.out.println("enter the length:");
		int n=s.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the elements in for sorting");
		for(int i=0;i<a.length;i++){
			a[i]=s.nextInt();
		}
		e.getSorted(a);
		

	}

}
