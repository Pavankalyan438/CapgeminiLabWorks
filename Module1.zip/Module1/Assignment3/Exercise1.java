package Capg.Assignment3;

import java.util.Scanner;

public class Exercise1 {

	int getSecondSmallest() {
		int temp = 0, i, j;
		Scanner sc = new Scanner(System.in);
		System.out.println("number of elements:");
		int n = sc.nextInt();
		System.out.println("enter the array of elements:");
		int[] a = new int[n];
		for (i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		for (i = 0; i < n; i++) {
			for (j = i + 1; j < n; j++) {
				if (a[i] > a[j]) {
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
		return a[1];
	}
	public static void main(String[] args) {
		Exercise1 e = new Exercise1();
		System.out.println(e.getSecondSmallest());
		// System.out.println(u);

	}

}
