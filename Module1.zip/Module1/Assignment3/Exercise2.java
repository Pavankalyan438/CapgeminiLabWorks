package Capg.Assignment3;

import java.util.Scanner;

public class Exercise2 {
	static int n;

	String[] order(String[] a) {
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i].compareToIgnoreCase(a[j]) > 0) {
					String temp = a[i]; 
					a[i] = a[j];
					a[j] = temp;
				}
			}
			//System.out.println(a[i]);
		}
		if (n % 2 == 0) {
			for (int i = 0; i < n / 2; i++) {
				String d=a[i].toUpperCase();
				System.out.println(d);
			}
			for (int i = n / 2; i < n; i++) {
				String k=a[i].toLowerCase();
				//System.out.println(k);
			}
		} else {
			for (int i = 0; i < n / 2 + 1; i++) {
				a[i].toUpperCase();
			}
			for (int i = n / 2 + 1; i < n; i++) {
				a[i].toLowerCase();
			}
		}
		return a;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter the number n:");
		n = s.nextInt();
		String[] a = new String[n];
		for (int i = 0; i < a.length; i++) {
			a[i] = s.next();
		}
		Exercise2 e = new Exercise2();
		System.out.println(e.order(a));

	}

}
