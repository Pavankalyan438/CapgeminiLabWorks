package Capg.Assignment3;

import java.util.Scanner;

public class Exersie4 {

	void repeatChar(char c[]) {
		
		char t;
		
		//Scanner sc = new Scanner(System.in);
		for (int i = 0; i < c.length; i++) {
			int count=1;
			if(c[i]=='9')
			{
				continue;
			}
			 
			for (int j =i+1; j < c.length; j++) {
				//System.out.println(c  [j]+" "+c[i+1]);
				
				if (c[i] == c[j]) {
					
					count++;
					c[j]='9';
				}
			}
			System.out.println(c[i] + " repeats " + count + " times");
		}

	}

	public static void main(String[] args) {
		Exersie4 e = new Exersie4();
		String s = "Capgemini";
		char[] c = new char[s.length()];
		for (int i = 0; i < s.length(); i++) {
			c[i] = s.charAt(i);
			//System.out.println(c[i]);
		}
		e.repeatChar(c);

	}

}
